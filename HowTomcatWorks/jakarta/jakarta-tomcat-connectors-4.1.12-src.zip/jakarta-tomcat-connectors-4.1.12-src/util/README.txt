This subpackage contains a set of common utilities copied out
of tomcat 3.3.

It probably doesn't belong in jakarta-tomcat-connectors, but perhaps
in something like jakarta-tomcat-util, or something.... [seguin].

To build, simply run ant.  The default target creates tomcat-util.jar
int ./build/lib.
